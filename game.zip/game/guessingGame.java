package game;
import javax.swing.*;
import java.util.Random; //imports
public class guessingGame {
public static void main(String[] args) {
game();
}
public static void game(){
int userNum,computerNum2; //declarations
userNum= Integer.parseInt(JOptionPane.showInputDialog(null,"PLEASE INPUT A NUMBER FROM 1-10","GUESS_THE NUMBER GAME",JOptionPane.INFORMATION_MESSAGE ));
Random number = new Random();//random number
 computerNum2=number.nextInt(10)+1;
 //*******************************************************************************************************************
if(userNum==computerNum2){
JOptionPane.showMessageDialog(null,"COMPUTERS NUMBER:" + "    "+computerNum2,"GUESS_THE NUMBER GAME",JOptionPane.INFORMATION_MESSAGE);
JOptionPane.showMessageDialog(null,"YOU GUESSED RIGHT....YOU WIN!!!" + "    ","GUESS_THE NUMBER GAME",JOptionPane.INFORMATION_MESSAGE);
}else{
//********************************************************************************************************************
while(!(computerNum2==userNum)){
    computerNum2=number.nextInt(10)+1;
JOptionPane.showMessageDialog(null,"COMPUTERS NUMBER:" + "    "+computerNum2,"GUESS_THE NUMBER GAME",JOptionPane.INFORMATION_MESSAGE);
JOptionPane.showMessageDialog(null,"YOU GUESSED WRONG.....YOU LOOSE!!!" + "    ","GUESS_THE NUMBER GAME",JOptionPane.INFORMATION_MESSAGE);
    userNum= Integer.parseInt(JOptionPane.showInputDialog(null,"PLEASE INPUT A NUMBER FROM 1-10","GUESS_THE NUMBER GAME",JOptionPane.INFORMATION_MESSAGE ));
}
}
}
}  